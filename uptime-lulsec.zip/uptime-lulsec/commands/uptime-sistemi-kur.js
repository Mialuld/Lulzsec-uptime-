const { EmbedBuilder, PermissionsBitField, getTextInputValue, TextInputBuilder, ButtonBuilder } = require("discord.js");
const db = require("Lulzsec_uyg");
const Discord = require("discord.js");

module.exports = {
    name: "uptime-sistemi-kur",
    description: 'Sunucunuza uptime sistemini kurarsınız aman ben size kurmayayimde.',
    type: 1,
    options: [
        {
            name: "kanal",
            description: "Sistem hangi kanala kuruyim aga",
            type: 7,
            channel_types: [0],
            required: true
        }
    ],
    run: async (client, interaction) => {

        const kanal = interaction.options.getChannel("kanal");
        const sistem = db.fetch(`uptimesistem_${interaction.guild.id}`)

        if(!sistem) {
            interaction.reply({ content: "Sistem sunucunuza kuruluyor bekle amk.", ephemeral: true })

            const embed = new EmbedBuilder()
            .setThumbnail(client.user.displayAvatarURL())
            .setTitle("Uptime Sistemi lulzsec_uyg")
            .setDescription(`
            Link Eklemek İçin \`Ekle\` Butonuna Tıkla.
            Link Silmek İçin \`Sil\` Butonuna Tıkla.
            Linklerinin Listesini Görmek İçin \`Liste\` Butonuna Tıkla.
            `)

            const row = new Discord.ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                .setLabel("Ekle")
                .setStyle(Discord.ButtonStyle.Success)
                .setCustomId("butonekle"),
                new ButtonBuilder()
                .setLabel("Sil")
                .setStyle(Discord.ButtonStyle.Danger)
                .setCustomId("butonsil"),
                new ButtonBuilder()
                .setLabel("Liste")
                .setStyle(Discord.ButtonStyle.Primary)
                .setCustomId("butonliste")
            )
            
            client.channels.cache.get(kanal.id).send({ embeds: [embed], components: [row] })
            db.set(`uptimesistem_${interaction.guild.id}`, kanal.id)
        }

        if(sistem) {
            interaction.reply({ content: "Uptime sunucunuzda online.\nSıfırlamak için (sıfırlama aga) `/uptime-sistemi-sıfırla`", ephemeral: true})
        }
     }
}